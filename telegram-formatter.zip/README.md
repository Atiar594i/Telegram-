# Telegram Formatter

Paste numbers into the input box and get formatted links like `t.me/+123456789`. Built with Next.js.

## Run Locally

```bash
npm install
npm run dev
```